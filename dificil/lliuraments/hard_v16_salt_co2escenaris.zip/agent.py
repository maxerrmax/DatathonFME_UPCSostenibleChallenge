"""
BatteryAgent — Mode Difícil (6.000 kWh, ±1.500 kW, solar ×12, mercat a 3 h).

Cada hora:
  1. Actualitza l'historial (preu/CO2 de la finestra de 3 h; consum, solar i meteo de l'hora anterior).
  2. Preveu 24 h amb LightGBM: preu i CO2 (+3..+23 h; les 3 primeres són exactes),
     consum i solar (+0..+23 h). Consum/preu: lag24 + residu; solar: mescla model + persistència.
  3. Resol un LP: min sum w_t * imp_t  amb  imp_t >= net_t + c_t - d_t, imp_t >= 0
     (l'excedent solar és gratuït i el que es descarrega de més es perd), més valor terminal.
  4. Aplica la primera acció amb un marge de prudència a la descàrrega i el clamp físic.
Blindat: qualsevol error -> regla simple / repòs, sortida sempre dins dels límits.
"""
import json, math
from pathlib import Path
import numpy as np
from scipy.optimize import linprog

try:
    import joblib, lightgbm as lgb
except Exception:  # pragma: no cover
    joblib = lgb = None

from feats import Hist, mkt_features, mkt_features2, load_features2, meas_features, set_cs, cs_value, net0_extra

ETA = 0.9 ** 0.5
HERE = Path(__file__).parent


def _num(x, default=float("nan")):
    try:
        v = float(x)
        return v if math.isfinite(v) else default
    except (TypeError, ValueError):
        return default


def _epoch_hour(ts, fallback):
    try:
        if hasattr(ts, "value"):                       # pandas.Timestamp
            return int(ts.value // 3_600_000_000_000)
        return int(np.datetime64(str(ts)[:19], "h").astype(np.int64))
    except Exception:
        return fallback


class BatteryAgent:
    def __init__(self, params=None):
        p = {"ratio": 0.6213, "q_term": 0.6, "term_scale": 1.0, "k_dis": 0.5, "pv_blend": 0.3,
             "horizon": 24, "k_future": 0.0, "sigma_mode": "global",
             "models": "models_all.pkl"}
        try:
            f = HERE / "parametres.json"
            if f.exists():
                p.update(json.loads(f.read_text()))
        except Exception:
            pass
        if params:
            p.update(params)
        self.p = p
        self.m = {}
        self.mk2 = {}
        self.ld2 = []
        self.n0 = None
        self.n0x = False
        self.n0q = []
        self.n0q_x = True
        self._q0 = None
        self.mkg = {}
        self.h0_max = None
        try:
            raw = p.get("_models")
            if raw is None:
                raw = joblib.load(HERE / p["models"])
            # LightGBM es desa com a text; la resta (XGBoost, sklearn, ensembles) com a objectes amb .predict
            raw = dict(raw)
            set_cs(raw.pop("pv_cs", None))
            self._h0 = raw.pop("hist0", None)
            mk2 = raw.pop("mkt2", None) or {}
            self.mk2 = {k: [(lgb.Booster(model_str=ms), list(cols), base) for ms, cols, base in v] for k, v in mk2.items()}
            self.ld2 = [(lgb.Booster(model_str=ms), list(cols), base) for ms, cols, base in (raw.pop("load2", None) or [])]
            self.mkg = {k: [(a, b_, lgb.Booster(model_str=ms), list(cols), kind) for a, b_, ms, cols, kind in v]
                        for k, v in (raw.pop("mktg", None) or {}).items()}
            self.n0x = bool(raw.pop("net0x", False))     # v14: el model net0 porta senyals de curt termini
            # v15: models de quantils del consum net de l'hora actual (incertesa condicionada a l'hora concreta)
            self.n0q = [(float(a), lgb.Booster(model_str=ms)) for a, ms in (raw.pop("net0q", None) or [])]
            self.n0q_x = bool(raw.pop("net0q_x", True))
            n0 = raw.pop("net0", None)
            self.n0 = lgb.Booster(model_str=n0) if n0 else None
            self.m = {k: (lgb.Booster(model_str=v) if isinstance(v, str) else v) for k, v in raw.items()}
        except Exception:
            self.m = {}
        self.hist = Hist()
        # historial inicial = dades d'entrenament (el dia abans de cada setmana de test és al train):
        # així els lags de 24/48/168 h existeixen des de la primera hora de cada setmana
        try:
            h0 = p.get("_hist0", getattr(self, "_h0", None)) if p.get("prefill", True) else None
            if h0:
                for k, (hh, vv) in h0.items():
                    for e, v in zip(hh, vv):
                        self.hist.put(k, e, v)
                self.h0_max = int(max(self.hist.d["price"])) if self.hist.d["price"] else None
        except Exception:
            pass
        self.jump_off = False                           # es desactiva si el calendari de salts no es compleix
        self.t_prev = None
        self.err = []                                   # errors recents de previsió de net (t-1)
        self.err_v = []                                 # variabilitat recent del consum net quan es va fer cada previsió
        self._co2_fc = {}                               # v15: previsions de CO2 passades (per mesurar trajectòries d'error)
        self._co2_err = []                              # vectors d'error log(real/previst) per a h = 3..23
        self.vol_pred = float("nan")
        self.pred_net0 = None
        self.hist_w = []
        self.cap, self.pmax = 6000.0, 1500.0
        self.max_len = 0                                # llargada màxima vista de la finestra de mercat
        self._raw_fc = {}                                 # prediccions CAUSALS de mercat anteriors (crues)


    # ------------------------------------------------------------------ previsions
    def _pred(self, key, X, kind):
        if self.p.get("no168"):
            X[:, 7] = np.nan                            # el lag setmanal generalitza malament
        lag = X[:, 5]
        if not self.m:
            out = lag.copy()
        else:
            d = self.m[key + "_dir"].predict(X, num_threads=1)
            r = lag + self.m[key + "_res"].predict(X, num_threads=1)
            out = np.where(np.isfinite(lag), r, d) if kind == "res" else d
        if key == "pv":
            last, last24 = X[:, 8], X[:, 8] - X[:, 9]
            ratio = np.clip(np.where(np.isfinite(last24) & (last24 > 50), last / np.maximum(last24, 1), 1.0), 0.3, 1.5)
            pers = lag * (1 + (ratio - 1) * np.exp(-X[:, 0] / 6.0))
            csp = X[:, -1]                                   # k_last * cel_clar(tau)
            if self.p.get("pv_cs", True):
                wcs = np.exp(-X[:, 0] / self.p.get("cs_tau", 3.0))
                pers = np.where(np.isfinite(csp), wcs * csp + (1 - wcs) * np.where(np.isfinite(pers), pers, csp), pers)
            a = self.p["pv_blend"]
            out = np.where(np.isfinite(pers), a * out + (1 - a) * pers, out)
            hod = X[:, 1]
            out = np.where((hod < 6) | (hod > 21), 0.0, np.maximum(out, 0.0))
        return np.where(np.isfinite(out), out, np.nan)

    def _pred_mkt2(self, key, t, hs):
        """Mitjana de models residuals (respecte a l'últim valor conegut o al perfil d'ahir desplaçat).
        Si el fitxer de models porta models per tram d'horitzó (+3..+5, +6..+11 h), aquests substitueixen l'ensemble
        a les seves hores (i l'ensemble només es calcula per a la resta, per no gastar temps)."""
        X = mkt_features2(self.hist, key, t, hs)
        k2 = X[:, 7]; xs = np.where(np.isfinite(X[:, 13]), X[:, 13], k2)
        xsl = np.where(np.isfinite(X[:, 13]) & (X[:, 13] > 0.3 * k2), X[:, 13], k2)
        res = np.full(len(hs), np.nan); grp = np.full(len(hs), np.nan)
        gm = self.p.get("grp_mix", 1.0)
        if gm > 0 and key in self.p.get("grp_keys", ("price", "co2")):
            hs_a = np.asarray(hs)
            for a, b_, bst, cols, kind in self.mkg.get(key, []):
                sel = (hs_a >= a) & (hs_a <= b_)
                if sel.any():
                    pr = bst.predict(X[sel][:, cols], num_threads=1)
                    grp[sel] = np.where(k2[sel] > 0, k2[sel] * np.exp(pr), k2[sel]) if kind == "log" else k2[sel] + pr
        need = ~np.isfinite(grp) if gm >= 1.0 else np.ones(len(hs), bool)
        if need.any():
            Xn = X[need]; out = []
            for b, cols, base in self.mk2[key]:
                pr = b.predict(Xn[:, cols], num_threads=1)
                if base == "logk2":                          # model del quocient (escala lliure)
                    out.append(np.where(k2[need] > 0, k2[need] * np.exp(pr), k2[need]))
                elif base == "logxs":
                    out.append(np.where(xsl[need] > 0, xsl[need] * np.exp(pr), xsl[need]))
                else:
                    out.append((xs if base == "xs" else k2)[need] + pr)
            res[need] = np.mean(out, axis=0)
        ok = np.isfinite(grp)
        res[ok] = np.where(np.isfinite(res[ok]), gm * grp[ok] + (1 - gm) * res[ok], grp[ok])
        return res

    def _pred_load2(self, t, hs):
        """Consum: perfil d'ahir desplaçat al nivell actual (hores properes) barrejat amb lag24 + residu (hores llunyanes)."""
        X = load_features2(self.hist, t, hs)
        def fb(*idx):
            b = X[:, idx[0]]
            for i in idx[1:]:
                b = np.where(np.isfinite(b), b, X[:, i])
            return np.where(np.isfinite(b), b, 1000.0)
        bases = {"lag24": fb(9, 5, 15), "xs": fb(13, 9, 5, 15)}
        pr = {base: bases[base] + b.predict(X[:, cols], num_threads=1) for b, cols, base in self.ld2}
        w = np.exp(-X[:, 0] / self.p.get("load_tau", 4.0))
        return w * pr["xs"] + (1 - w) * pr["lag24"]

    def _forecast(self, t, price3, co2_3):
        H = 24
        price = np.full(H, np.nan); co2 = np.full(H, np.nan)
        price[:len(price3)] = price3; co2[:len(co2_3)] = co2_3
        hs = list(range(len(price3), H))
        if hs:
            if self.mk2:
                price[hs] = self._pred_mkt2("price", t, hs)
                co2[hs] = self._pred_mkt2("co2", t, hs)
            else:
                price[hs] = self._pred("price", mkt_features(self.hist, "price", t, hs), "res")
                co2[hs] = self._pred("co2", mkt_features(self.hist, "co2", t, hs), "dir")
        hs_all = list(range(H))
        if self.ld2:
            load = self._pred_load2(t, hs_all)
        else:
            load = self._pred("load", meas_features(self.hist, "load", t, hs_all), "res")
        pv = self._pred("pv", meas_features(self.hist, "pv", t, hs_all), "dir")
        # hora actual: model directe del consum net (consum - solar), barrejat amb la previsió per separat
        mix = self.p.get("net0_mix", 0.5)
        if self.n0 is not None and mix > 0:
            try:
                x0 = [load_features2(self.hist, t, [0])[0], meas_features(self.hist, "pv", t, [0])[0]]
                if self.n0x:
                    x0.append(net0_extra(self.hist, t))
                x0 = np.concatenate(x0)
                nd = float(self.n0.predict(x0.reshape(1, -1), num_threads=1)[0])
                if np.isfinite(nd) and np.isfinite(load[0]) and np.isfinite(pv[0]):
                    load[0] = mix * nd + (1 - mix) * (load[0] - pv[0]) + pv[0]
            except Exception:
                pass
        self._q0 = None
        if self.n0q and self.p.get("scen_q", 0.0) > 0:
            try:
                xq = [load_features2(self.hist, t, [0])[0], meas_features(self.hist, "pv", t, [0])[0]]
                if self.n0q_x:
                    xq.append(net0_extra(self.hist, t))
                xq = np.concatenate(xq).reshape(1, -1)
                al = np.array([a for a, _ in self.n0q]); qv = np.sort([float(b.predict(xq, num_threads=1)[0]) for _, b in self.n0q])
                if np.isfinite(qv).all():
                    self._q0 = (al, qv)
            except Exception:
                self._q0 = None
        def fill(a, default):
            a = np.asarray(a, float)
            if not np.isfinite(a).any():
                return np.full(len(a), default)
            idx = np.arange(len(a)); ok = np.isfinite(a)
            return np.interp(idx, idx[ok], a[ok])
        price = fill(price, price3[0] if len(price3) else 0.12)
        co2 = fill(co2, co2_3[0] if len(co2_3) else 0.10)
        load = fill(load, 1100.0); pv = fill(pv, 0.0)
        cheat = self.p.get("_cheat")                    # NOMÉS diagnòstic local (mai al lliurament)
        if cheat:
            tbl, keys = cheat
            for k, arr in (("price", price), ("co2", co2), ("load", load), ("pv", pv)):
                if k in keys:
                    for h in range(H):
                        v = tbl[k].get(t + h)
                        if v is not None:
                            arr[h] = v
        # Correcció causal en línia (v12 de l'equip, generalitzada). A t ja coneixem exactament t, t+1, t+2;
        # comparem aquests valors amb les previsions crues fetes fa L hores (per defecte L=3, horitzons 3..5),
        # estimem el biaix recent i el sumem (o multipliquem) a les previsions futures, decreixent amb l'horitzó.
        # Només es fan servir dades conegudes en l'instant t. Els valors per defecte reprodueixen la v12 exacta.
        for key, arr, known_v, on, clip_d in (("co2", co2, co2_3, self.p.get("co2_cal", True), 0.06),
                                              ("price", price, price3, self.p.get("price_cal", False), 0.06)):
            try:
                store = self._raw_fc.setdefault(key, {})
                raw = arr.copy()
                pre = key + "_"
                n_exact = min(3, len(known_v))
                if on and n_exact > 0:
                    mult = self.p.get(pre + "cal_mult", False)
                    errs = []
                    for L in self.p.get(pre + "cal_lags", [3]):
                        old = store.get(t - L)
                        if old is None:
                            continue
                        for j in range(n_exact):
                            i = j + L
                            if 3 <= i < len(old) and np.isfinite(old[i]) and np.isfinite(arr[j]):
                                if mult:
                                    if old[i] > 0 and arr[j] > 0:
                                        errs.append(math.log(arr[j] / old[i]))
                                else:
                                    errs.append(arr[j] - old[i])
                    if errs and (len(errs) >= n_exact or self.p.get(pre + "cal_partial", False)):
                        agg = np.mean if self.p.get(pre + "cal_agg", "median") == "mean" else np.median
                        c = self.p.get(pre + "cal_clip", 0.5 if mult else clip_d)
                        bias = float(np.clip(agg(errs), -c, c)) * self.p.get(pre + "cal_k", 1.0)
                        h = np.arange(3, len(arr))
                        tau = self.p.get(pre + "cal_tau", 8.0)
                        dec = np.exp(-(h - 3) / tau) if tau > 0 else np.ones(len(h))
                        arr[3:] = np.clip(arr[3:] * np.exp(bias * dec), 0.0, 1.0) if mult else \
                            np.clip(arr[3:] + bias * dec, 0.0, 1.0)
                store[t] = raw
                for k_ in list(store):                  # memòria acotada i segura si el timestamp salta entre blocs
                    if k_ < t - 6:
                        del store[k_]
            except Exception:
                pass
        return price, co2, load, pv

    # ------------------------------------------------------------------ optimització
    def _lp(self, w, net, soc0, v_term, dmax0, scen=None):
        H = len(w); cap, pm = self.cap, self.pmax
        K = 0 if scen is None else len(scen)
        L = np.tril(np.ones((H, H)))
        Asoc = np.hstack([L * ETA, -L / ETA, np.zeros((H, H + K))])      # SOC_k - soc0
        # net + c - d - imp <= 0
        Aimp = np.hstack([np.eye(H), -np.eye(H), -np.eye(H), np.zeros((H, K))])
        A = np.vstack([Asoc, -Asoc, Aimp])
        b = np.concatenate([np.full(H, cap - 1e-3 - soc0), np.full(H, soc0 - 1e-3), -net])
        cost = np.concatenate([np.zeros(2 * H), w, np.zeros(K)]) - v_term * Asoc[-1]
        bounds = [(0, pm)] * H + [(0, pm)] * H + [(0, None)] * (H + K)
        bounds[H] = (0, max(0.0, min(pm, dmax0)))
        if K:
            # hora actual estocàstica: cost esperat de la importació sobre K escenaris del consum net
            # (el que es descarrega de més es perd; el que es carrega de més s'importa)
            S = np.zeros((K, 3 * H + K)); S[:, 0] = 1.0; S[:, H] = -1.0
            S[np.arange(K), 3 * H + np.arange(K)] = -1.0
            A = np.vstack([A, S]); b = np.concatenate([b, -(net[0] + np.asarray(scen, float))])
            cost[2 * H] = 0.0; cost[3 * H:] = w[0] / K
            b[2 * H] = 1e9                                   # la restricció determinista de l'hora 0 queda inactiva
        r = linprog(cost, A_ub=A, b_ub=b, bounds=bounds, method="highs")
        if r.status != 0 or r.x is None:
            return None
        return r.x[:H] - r.x[H:2 * H]

    def _lp_sto(self, Wk, net, soc0, v_term, dmax0, scen=None, pk=None):
        """LP en dues etapes amb K escenaris del pes w (CO2): l'acció de l'hora actual és comuna i les hores 1..H-1
        es decideixen per escenari (quan arribi la informació). Cost esperat = mitjana ponderada dels escenaris."""
        import scipy.sparse as sp
        K, H = Wk.shape; cap, pm = self.cap, self.pmax; G = H - 1
        pk = np.full(K, 1.0 / K) if pk is None else np.asarray(pk, float) / np.sum(pk)
        sc0 = np.zeros(1) if scen is None else np.asarray(scen, float); J = len(sc0)
        n = 2 + J + K * 3 * G
        key = (K, H, J)
        cache = getattr(self, "_sto_cache", {})
        if key not in cache:                                # l'estructura de la matriu només depèn de (K, H, J)
            R, C, V = [], [], []
            R += [0, 0, 1, 1]; C += [0, 1, 0, 1]; V += [ETA, -1 / ETA, -ETA, 1 / ETA]
            j = np.arange(J); r0 = 2
            R += np.repeat(r0 + j, 3).tolist(); C += np.column_stack([np.zeros(J, int), np.ones(J, int), 2 + j]).ravel().tolist()
            V += [1.0, -1.0, -1.0] * J
            r = r0 + J
            ii, jj = np.tril_indices(G)                      # SOC: suma acumulada de c_k i d_k
            for k in range(K):
                o = 2 + J + k * 3 * G
                for sign in (1.0, -1.0):
                    rows = r + np.arange(G)
                    R += np.concatenate([rows, rows, r + ii, r + ii]).tolist()
                    C += np.concatenate([np.zeros(G, int), np.ones(G, int), o + jj, o + G + jj]).tolist()
                    V += np.concatenate([np.full(G, sign * ETA), np.full(G, -sign / ETA),
                                         np.full(len(ii), sign * ETA), np.full(len(ii), -sign / ETA)]).tolist()
                    r += G
                rows = r + np.arange(G); h = np.arange(G)
                R += np.repeat(rows, 3).tolist(); C += np.column_stack([o + h, o + G + h, o + 2 * G + h]).ravel().tolist()
                V += [1.0, -1.0, -1.0] * G
                r += G
            cache[key] = sp.csr_matrix((V, (R, C)), shape=(r, n)); self._sto_cache = cache
        Aub = cache[key]
        bk = np.concatenate([np.full(G, cap - 1e-3 - soc0), np.full(G, soc0 - 1e-3), -np.asarray(net[1:], float)])
        b = np.concatenate([[cap - 1e-3 - soc0, soc0 - 1e-3], -(net[0] + sc0), np.tile(bk, K)])
        cost = np.zeros(n); cost[2:2 + J] = Wk[0, 0] / J
        cost[0] = -v_term * ETA; cost[1] = v_term / ETA         # valor terminal (comú a tots els escenaris)
        blk = np.concatenate([np.full(G, -v_term * ETA), np.full(G, v_term / ETA), np.zeros(G)])
        cst = (pk[:, None] * (blk[None, :] + np.hstack([np.zeros((K, 2 * G)), Wk[:, 1:]]))).ravel()
        cost[2 + J:] = cst
        lo = np.zeros(n); hi = np.concatenate([[pm, max(0.0, min(pm, dmax0))], np.full(J, np.inf),
                                               np.tile(np.concatenate([np.full(2 * G, pm), np.full(G, np.inf)]), K)])
        res = linprog(cost, A_ub=Aub, b_ub=b, bounds=np.column_stack([lo, hi]), method="highs")
        if res.status != 0 or res.x is None:
            return None
        return np.array([res.x[0] - res.x[1]])

    def _clamp(self, soc, a):
        mc = max(0.0, min(self.pmax, (self.cap - soc) / ETA - 1e-3))
        md = max(0.0, min(self.pmax, soc * ETA - 1e-3))
        a = max(-md, min(mc, a))
        return 0.0 if (not math.isfinite(a) or abs(a) < 1e-6) else float(a)

    # ------------------------------------------------------------------ salts entre setmanes
    def _segment(self, t):
        """(E, J, final): última hora del tram actual, primera hora del tram següent i si la simulació s'acaba a E.
        Les setmanes de test són els últims 7 dies de cada mes i el servidor les simula seguides: després de
        l'última hora d'un mes ve la primera hora de la setmana de test del mes següent (el SOC es conserva)."""
        if self.jump_off or not self.p.get("jump", True) or self.h0_max is None:
            return None
        segs = self.p.get("_segs")                      # NOMÉS validació local: trams explícits [(inici, fi), ...]
        if segs is not None:
            for i, (a, b) in enumerate(segs):
                if a <= t <= b:
                    last = i + 1 >= len(segs) or self.p.get("final_all", False)
                    return int(b), (None if last else int(segs[i + 1][0])), last
            return None
        off = int(self.p.get("seg_off", 0))
        m = np.datetime64(int(t), "h").astype("datetime64[M]")
        d_end = (m + 1).astype("datetime64[D]") - 1 - off
        E = int(d_end.astype("datetime64[h]").astype(np.int64)) + 23
        if t > E or t < E - 167:
            return None
        d_next = (m + 2).astype("datetime64[D]") - 7 - off
        J = int(d_next.astype("datetime64[h]").astype(np.int64))
        # sense dades de train abans de J -> final de la simulació. Amb final_all, cada final de mes es tracta com un
        # possible final: la bateria es buida a les últimes hores de cada setmana (es torna a carregar de matinada)
        return E, J, (J - 1 > self.h0_max) or bool(self.p.get("final_all", False))

    # ------------------------------------------------------------------ pas
    def act(self, obs):
        try:
            return self._act(obs)
        except Exception:
            try:
                return self._clamp(_num((obs or {}).get("soc_kwh"), 0.0), 0.0)
            except Exception:
                return 0.0

    def _act(self, obs):
        # sense cap_max_kwh/power_max_kw a obs -> Mode Estàndard (2.000 kWh, ±500 kW)
        self.cap = _num(obs.get("cap_max_kwh"), 2000.0); self.pmax = _num(obs.get("power_max_kw"), 500.0)
        soc = min(self.cap, max(0.0, _num(obs.get("soc_kwh"), self.cap / 2)))
        t = _epoch_hour(obs.get("timestamp"), (self.t_prev + 1) if self.t_prev is not None else 0)
        jumped = self.t_prev is not None and t != self.t_prev + 1
        if self.t_prev is not None and not self.jump_off:
            sp = self._segment(self.t_prev)             # comprovació: el salt observat ha de ser el previst
            exp = (self.t_prev + 1) if (sp is None or sp[0] != self.t_prev or sp[1] is None) else sp[1]
            if t != exp:
                # salt inesperat: només es manté el calendari si hem anat a parar a l'inici d'un altre tram
                # (p. ex. falta una setmana sencera); si no, es torna al comportament sense salts
                sn = self._segment(t)
                segs = self.p.get("_segs")
                starts = [a for a, _ in segs] if segs is not None else ([sn[0] - 167] if sn else [])
                if not (jumped and t in starts):
                    self.jump_off = True
        self.t_prev = t
        seg = self._segment(t)
        n_left, J, final = (seg[0] - t + 1, seg[1], seg[2]) if seg else (None, None, False)
        # historial
        pr = [_num(x) for x in (obs.get("preus_properes_24h") or [])]
        cr = [_num(x) for x in (obs.get("co2_properes_24h") or [])]
        if not pr or not math.isfinite(pr[0]):
            pr = [_num(obs.get("preu_actual"), self.hist.get("price", t - 1))] + pr[1:]
        if not cr or not math.isfinite(cr[0]):
            cr = [_num(obs.get("co2_actual"), self.hist.get("co2", t - 1))] + cr[1:]
        def key_of(i):                                  # la finestra de mercat pot travessar el salt de setmana
            return t + i if (n_left is None or J is None or i < n_left) else J + (i - n_left)
        for i, v in enumerate(pr):
            self.hist.put("price", key_of(i), v)
        for i, v in enumerate(cr):
            self.hist.put("co2", key_of(i), v)
        nd = obs.get("noves_dades_5min") or {}
        ld, pv = _num(nd.get("ultim_consum_kw")), _num(nd.get("ultima_solar_kw"))
        # després d'un salt, les mesures de "l'última hora" són de la setmana anterior (un mes abans): no són de t-1
        if not (jumped and self.p.get("jump_meas", True)):
            self.hist.put("load", t - 1, ld); self.hist.put("pv", t - 1, pv)
            self.hist.put("irr", t - 1, _num(nd.get("irradiancia_wm2"))); self.hist.put("temp", t - 1, _num(nd.get("temp_ambient_c")))
            self.hist.put("vent", t - 1, _num(nd.get("vent_ms")))
        if self.pred_net0 is not None and math.isfinite(ld) and math.isfinite(pv):
            self.err.append(((t - 1) % 24, (ld - pv) - self.pred_net0)); self.err = self.err[-int(self.p.get("err_mem", 336)):]
            self.err_v.append(self.vol_pred); self.err_v = self.err_v[-int(self.p.get("err_mem", 336)):]

        # tots els valors de mercat coneguts consecutius (3 h al Mode Difícil, 24 h a l'Estàndard)
        def known(v, d):
            out = []
            for x in v[:24]:
                if not math.isfinite(x):
                    break
                out.append(x)
            return out or [d]
        tbl = self.p.get("_fc_table")
        if tbl is not None and t in tbl:
            price, co2, load, pvf = [np.array(x, float) for x in tbl[t]]
            kp, kc = known(pr, 0.12), known(cr, 0.10)          # els valors coneguts són exactes
            price[:len(kp)] = kp; co2[:len(kc)] = kc
        else:
            price, co2, load, pvf = self._forecast(t, known(pr, 0.12), known(cr, 0.10))
        rec = self.p.get("_record")
        if rec is not None:
            rec[t] = (price.copy(), co2.copy(), load.copy(), pvf.copy())
        if int(self.p.get("co2_sto", 0)) > 0 and len(co2) == 24:
            t0 = t - 21                                     # previsió feta a t0: ara coneixem el CO2 fins a t0+23
            f0 = self._co2_fc.pop(t0, None)
            if f0 is not None:
                a = np.array([self.hist.get("co2", t0 + h) for h in range(3, 24)])
                if np.isfinite(a).all() and (a > 0).all() and (f0[3:] > 0).all():
                    self._co2_err.append(np.log(a / f0[3:])); self._co2_err = self._co2_err[-int(self.p.get("co2_mem", 336)):]
            self._co2_fc[t] = co2.copy()
            for k_ in [k_ for k_ in self._co2_fc if k_ < t - 22]:
                del self._co2_fc[k_]
        Hh = int(max(2, min(24, self.p.get("horizon", 24))))
        # final de la simulació: si la finestra de mercat s'escurça, només queden len(pr) hores
        n_mkt = len(pr); self.max_len = max(self.max_len, n_mkt)
        fi = 0 < n_mkt < self.max_len
        end_left = None
        if not fi and self.p.get("end_cal", False) and self.h0_max is not None:
            # final del test per calendari, independent del salt: les setmanes de test són els últims 7 dies de cada mes
            # i, després de l'última (agost), no hi ha dades d'entrenament. Si la setmana actual és l'última, en les
            # últimes hores es planifica només fins al final (l'energia que quedi a la bateria es perdria)
            m = np.datetime64(int(t), "h").astype("datetime64[M]")
            E = int((m + 1).astype("datetime64[D]").astype("datetime64[h]").astype(np.int64)) - 1
            Jn = int(((m + 2).astype("datetime64[D]") - 7).astype("datetime64[h]").astype(np.int64))
            if Jn - 1 > self.h0_max and 0 <= E - t:
                end_left = E - t + 1
        if not fi and n_left is not None and final and self.p.get("jump_final", True):
            end_left = n_left                           # última setmana (calendari del salt o trams de validació)
        # final conegut: en les últimes end_h hores es planifica només fins al final (l'energia sobrant no val res)
        if not fi and end_left is not None and end_left <= min(len(price), self.p.get("end_h", 24)):
            fi = True; Hh = max(1, min(Hh, end_left))
        if fi:
            Hh = max(1, min(Hh, n_mkt)) if 0 < n_mkt < self.max_len else Hh
        elif n_left is not None and n_left < len(price):
            if final:
                pass
            elif J is not None and self.p.get("jump_plan", True):
                # les hores de després del salt són les primeres de la setmana de test següent: valors reals de la
                # finestra de mercat si ja hi són, i si no els del dia anterior (que és a les dades d'entrenament)
                for k in range(max(0, n_left), len(price)):
                    tau = J + (k - n_left)
                    for name, arr in (("price", price), ("co2", co2), ("load", load), ("pv", pvf)):
                        v = self.hist.get(name, tau) if name in ("price", "co2") else float("nan")
                        if not math.isfinite(v):
                            v = self.hist.get(name, tau - 24)
                        if math.isfinite(v):
                            arr[k] = v
        price, co2, load, pvf = price[:Hh], co2[:Hh], load[:Hh], pvf[:Hh]
        self.pred_net0 = float(load[0] - pvf[0])        # error de previsió mesurat sense biaix
        n1 = self.hist.get("load", t - 1) - self.hist.get("pv", t - 1); n2 = self.hist.get("load", t - 2) - self.hist.get("pv", t - 2)
        self.vol_pred = abs(n1 - n2) if (math.isfinite(n1) and math.isfinite(n2)) else float("nan")
        # biaix deliberat: descarregar de més es perd del tot, descarregar de menys només ajorna
        load = np.maximum(load + self.p.get("load_bias", 0.0), 0.0)
        pvf = pvf * self.p.get("pv_bias", 1.0)
        net = load - pvf
        w = 0.7 * co2 + 0.3 * self.p["ratio"] * price
        self.hist_w.append(float(w[0]))
        ref = np.concatenate([w, self.hist_w[-72:]])
        v = 0.0 if fi else self.p["term_scale"] * ETA * float(np.quantile(ref, self.p["q_term"]))
        # prudència a la descàrrega de l'hora actual: net previst - k * error típic
        sig = float(np.mean([abs(e) for _, e in self.err])) if len(self.err) >= 12 else 80.0
        if self.p.get("sigma_mode") == "hod":
            same = [abs(e) for h_, e in self.err if h_ == t % 24]
            if len(same) >= 3:
                sig = float(np.mean(same))
        dmax0 = max(0.0, float(net[0]) - self.p["k_dis"] * sig)
        scen = None
        K = int(self.p.get("scen", 0))
        if K:
            h0 = t % 24
            win = [i for i, (h_, e) in enumerate(self.err) if min((h_ - h0) % 24, (h0 - h_) % 24) <= self.p.get("scen_win", 1)]
            vnow = self.vol_pred
            fr = self.p.get("scen_vol", 0.0)                # v15: només els errors d'hores amb variabilitat semblant
            if fr > 0 and math.isfinite(vnow) and len(self.err_v) == len(self.err):
                cand = [i for i in win if math.isfinite(self.err_v[i])]
                nkeep = max(8, int(round(fr * len(cand))))
                if len(cand) > nkeep:
                    win = sorted(cand, key=lambda i: abs(self.err_v[i] - vnow))[:nkeep]
            pool = [self.err[i][1] for i in win]
            if len(pool) < 8:
                pool = [e for _, e in self.err]
            qs = (np.arange(K) + 0.5) / K
            if len(pool) >= 8:
                scen = np.quantile(pool, qs) * self.p.get("scen_scale", 1.0)
            else:
                from statistics import NormalDist
                scen = np.array([NormalDist().inv_cdf(q) for q in qs]) * self.p.get("scen_s0", 100.0)
            if self._q0 is not None:
                al, qv = self._q0
                ctr = self.pred_net0 if self.p.get("scen_q_abs", False) else np.interp(0.5, al, qv)
                off = (np.interp(qs, al, qv) - ctr) * self.p.get("scen_q_scale", 1.0)
                a_ = self.p.get("scen_q", 0.0)
                scen = a_ * off + (1 - a_) * np.asarray(scen, float)
            st = self.p.get("_scen_table")
            if st is not None and t in st:
                scen = np.asarray(st[t], float) - float(net[0])
            dmax0 = self.pmax
        net_plan = np.asarray(net, float).copy()
        kf = self.p.get("end_kf", self.p.get("k_future", 0.0)) if (fi and end_left is not None) else self.p.get("k_future", 0.0)
        if kf:
            net_plan[1:] = net_plan[1:] - kf * sig * np.sqrt(np.arange(1, len(net_plan)))
        P = None
        Ks = int(self.p.get("co2_sto", 0))
        if Ks > 0 and len(self._co2_err) >= int(self.p.get("co2_sto_min", 24)) and len(w) >= 6:
            try:
                E = np.array(self._co2_err)
                L_ = min(len(w), 24) - 3
                key = E[:, :int(self.p.get("co2_sto_key", 8))].mean(axis=1)
                grp = np.array_split(np.argsort(key), Ks)
                Ek = np.array([E[g_, :L_].mean(axis=0) for g_ in grp]); pk = np.array([len(g_) for g_ in grp], float)
                if self.p.get("co2_sto_center", True):
                    Ek = Ek - (pk[:, None] * Ek).sum(axis=0) / pk.sum()
                Ek = Ek * self.p.get("co2_sto_scale", 1.0)
                Wk = np.tile(w, (Ks, 1))
                Wk[:, 3:3 + L_] = 0.7 * co2[None, 3:3 + L_] * np.exp(Ek) + 0.3 * self.p["ratio"] * price[None, 3:3 + L_]
                P = self._lp_sto(Wk, net_plan, soc, v, dmax0, scen, pk)
            except Exception:
                P = None
        if P is None:
            P = self._lp(w, net_plan, soc, v, dmax0, scen)
        if P is None:
            a = 0.0
        else:
            a = float(P[0])
        return self._clamp(soc, a)
